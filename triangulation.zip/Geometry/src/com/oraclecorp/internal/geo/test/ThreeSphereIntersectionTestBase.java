package com.oraclecorp.internal.geo.test;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;

import com.oraclecorp.internal.geo.Point3D;
import com.oraclecorp.internal.geo.Sphere;
import com.oraclecorp.internal.geo.SphereIntersector;

public class ThreeSphereIntersectionTestBase
{
    protected Sphere sphere1;
    protected Sphere sphere2;
    protected Sphere sphere3;
    protected double epsilon;
    protected Point3D[] expectedValue;
 
    public ThreeSphereIntersectionTestBase()
    {
    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception
    {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception
    {
    }
    
    public void testSphereEquations()
    {
        List<Sphere> spheres = Arrays.asList(sphere1, sphere2, sphere3);
        testSphereEquations(spheres, 0, epsilon);
    }
    
    static protected void testSphereEquations(List<Sphere> spheres, int index, double epsilon)
    {
        for (int i = index; i < spheres.size(); i++)
        {
            java.util.Collections.swap(spheres, i, index);
            testSphereEquations(spheres, index+1, epsilon);
            java.util.Collections.swap(spheres, index, i);
        }
        
        if (index == spheres.size() - 1)
            testSphereEquationPermutation(spheres, epsilon);
    }

    static protected void testSphereEquationPermutation(List<Sphere> spheres, double epsilon)
    {
        Sphere sphereA = spheres.get(0);
        Sphere sphereB = spheres.get(1);
        Sphere sphereC = spheres.get(2);
        
        Point3D[] intersection = SphereIntersector.getIntersection(sphereA, sphereB, sphereC, epsilon);
        
        // NOTE: This is just one test instead of 6 because the intersection isn't correct unless
        // all of the equations are true.
        assertTrue(
            Math.abs(
                (intersection[0].x - sphereA.center.x)*(intersection[0].x - sphereA.center.x)
                + (intersection[0].y - sphereA.center.y)*(intersection[0].y - sphereA.center.y)
                + (intersection[0].z - sphereA.center.z)*(intersection[0].z - sphereA.center.z)
                - (sphereA.radius * sphereA.radius)) < epsilon

            && Math.abs(
                (intersection[1].x - sphereA.center.x)*(intersection[1].x - sphereA.center.x)
                + (intersection[1].y - sphereA.center.y)*(intersection[1].y - sphereA.center.y)
                + (intersection[1].z - sphereA.center.z)*(intersection[1].z - sphereA.center.z)
                - (sphereA.radius * sphereA.radius)) < epsilon
                
            && Math.abs(
                (intersection[0].x - sphereB.center.x)*(intersection[0].x - sphereB.center.x)
                + (intersection[0].y - sphereB.center.y)*(intersection[0].y - sphereB.center.y)
                + (intersection[0].z - sphereB.center.z)*(intersection[0].z - sphereB.center.z)
                - (sphereB.radius * sphereB.radius)) < epsilon
                
            && Math.abs(
                (intersection[1].x - sphereB.center.x)*(intersection[1].x - sphereB.center.x)
                + (intersection[1].y - sphereB.center.y)*(intersection[1].y - sphereB.center.y)
                + (intersection[1].z - sphereB.center.z)*(intersection[1].z - sphereB.center.z)
                - (sphereB.radius * sphereB.radius)) < epsilon
                
            && Math.abs(
                (intersection[0].x - sphereC.center.x)*(intersection[0].x - sphereC.center.x)
                + (intersection[0].y - sphereC.center.y)*(intersection[0].y - sphereC.center.y)
                + (intersection[0].z - sphereC.center.z)*(intersection[0].z - sphereC.center.z)
                - (sphereC.radius * sphereC.radius)) < epsilon
                
            && Math.abs(
                (intersection[1].x - sphereC.center.x)*(intersection[1].x - sphereC.center.x)
                + (intersection[1].y - sphereC.center.y)*(intersection[1].y - sphereC.center.y)
                + (intersection[1].z - sphereC.center.z)*(intersection[1].z - sphereC.center.z)
                - (sphereC.radius * sphereC.radius)) < epsilon);
    }
    
    public void testExpectedValue()
    {
        List<Sphere> spheres = Arrays.asList(sphere1, sphere2, sphere3);
        testExpectedValue(spheres, 0, expectedValue, epsilon);
    }
    
    static protected void testExpectedValue(List<Sphere> spheres, int index, Point3D[] expectedValue, double epsilon)
    {
        for (int i = index; i < spheres.size(); i++)
        {
            java.util.Collections.swap(spheres, i, index);
            testExpectedValue(spheres, index+1, expectedValue, epsilon);
            java.util.Collections.swap(spheres, index, i);
        }
        
        if (index == spheres.size() - 1)
            testExpectedValuePermutation(spheres, expectedValue, epsilon);

    }
    
    static protected void testExpectedValuePermutation(List<Sphere> spheres, Point3D[] expectedValue, double epsilon)
    {
        Sphere sphereA = spheres.get(0);
        Sphere sphereB = spheres.get(1);
        Sphere sphereC = spheres.get(2);

        Point3D[] intersection = SphereIntersector.getIntersection(sphereA, sphereB, sphereC, epsilon);
      
        assertTrue(
             Math.abs(intersection[0].x - expectedValue[0].x) < epsilon
          && Math.abs(intersection[0].y - expectedValue[0].y) < epsilon
          && Math.abs(intersection[0].z - expectedValue[0].z) < epsilon
          && Math.abs(intersection[1].x - expectedValue[1].x) < epsilon
          && Math.abs(intersection[1].y - expectedValue[1].y) < epsilon
          && Math.abs(intersection[1].z - expectedValue[1].z) < epsilon);
        
    }
}
