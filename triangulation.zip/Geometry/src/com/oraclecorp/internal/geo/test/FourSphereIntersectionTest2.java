package com.oraclecorp.internal.geo.test;

import org.junit.Before;
import org.junit.Test;

import com.oraclecorp.internal.geo.Point3D;
import com.oraclecorp.internal.geo.Sphere;

public class FourSphereIntersectionTest2 extends FourSphereIntersectionTestBase
{

    @Override
    @Before
    public void setUp() throws Exception
    {
        super.setUp();

        sphere1 = new Sphere(new Point3D(1.0, 2.0, 3.0), 3.0);
        sphere2 = new Sphere(new Point3D(2.0, 3.0, 1.0), 3.0);
        sphere3 = new Sphere(new Point3D(3.0, 1.0, 2.0), 3.0);
        sphere4 = new Sphere(new Point3D(0.52752523165195, 8.52752523165195, 14.52752523165195), Math.sqrt(9+25+121));
        epsilon = 0.0000001;
        
        expectedValue = new Point3D(3.52752523165195, 3.52752523165195, 3.52752523165195);
    }

    @Test
    public void testSphereEquations()
    {
        super.testSphereEquations();
    }
    
    @Test
    public void testExpectedValue()
    {
        super.testExpectedValue();
    }
}
