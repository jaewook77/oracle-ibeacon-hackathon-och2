package com.oraclecorp.internal.geo.test;

import org.junit.Before;

import com.oraclecorp.internal.geo.Point2D;

/**
 * Tests that having two of the three circles concentric (same center) results in null because
 * there is not a single point of intersection. 
 */
public class Point2DConcentricTest extends Point2DTestBase
{

    @Override
    @Before
    public void setUp() throws Exception
    {
        super.setUp();
        
        point1 = new Point2D(2.0, 1.0);
        point2 = point1;
        point3 = new Point2D(5.0, 4.0);

        distance1 = 3.0;
        distance2 = distance1;
        distance3 = 6.0;

        expectedLocation = null;
    }
}
