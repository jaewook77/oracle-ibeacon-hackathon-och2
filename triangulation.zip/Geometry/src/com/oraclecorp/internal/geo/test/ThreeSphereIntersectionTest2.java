package com.oraclecorp.internal.geo.test;

import org.junit.Before;
import org.junit.Test;

import com.oraclecorp.internal.geo.Point3D;
import com.oraclecorp.internal.geo.Sphere;

public class ThreeSphereIntersectionTest2 extends ThreeSphereIntersectionTestBase
{

    @Override
    @Before
    public void setUp() throws Exception
    {
        super.setUp();

        sphere1 = new Sphere(new Point3D(1.0, 2.0, 3.0), 3.0);
        sphere2 = new Sphere(new Point3D(2.0, 3.0, 1.0), 3.0);
        sphere3 = new Sphere(new Point3D(3.0, 1.0, 2.0), 3.0);
        epsilon = 0.0000001;
        
        expectedValue = new Point3D[2];
        expectedValue[0] = new Point3D(3.52752523165195, 3.52752523165195, 3.52752523165195);
        expectedValue[1] = new Point3D(0.472474768348053, 0.472474768348053, 0.472474768348053);
    }

    @Test
    public void testSphereEquations()
    {
        super.testSphereEquations();
    }
    
    @Test
    public void testExpectedValue()
    {
        super.testExpectedValue();
    }
}
