package com.oraclecorp.internal.geo.test;

import org.junit.Before;

import com.oraclecorp.internal.geo.Point2D;

public class Point2DIdenticalYCoordinateTest extends Point2DTestBase
{

    @Override
    @Before
    public void setUp() throws Exception
    {
        super.setUp();
        
        point1 = new Point2D(4.0, 4.0);
        point2 = new Point2D(0.0, 4.0);
        point3 = new Point2D(0.0, 0.0);

        double distance = Math.sqrt((2.0 * 2.0) + (2.0 * 2.0));
        distance1 = distance;
        distance2 = distance;
        distance3 = distance;

        expectedLocation = new Point2D(2.0, 2.0);
    }

}
