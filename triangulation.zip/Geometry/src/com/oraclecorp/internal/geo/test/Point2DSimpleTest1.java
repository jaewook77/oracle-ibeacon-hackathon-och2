package com.oraclecorp.internal.geo.test;

import org.junit.Before;

import com.oraclecorp.internal.geo.Point2D;

public class Point2DSimpleTest1 extends Point2DTestBase
{
    @Override
    @Before
    public void setUp() throws Exception
    {
        super.setUp();
        
        point1 = new Point2D(0.0, 5.0);
        point2 = new Point2D(4.0, 3.0);
        point3 = new Point2D(2.0, 1.0);

        distance1 = Math.sqrt(8.0);
        distance2 = 2.0;
        distance3 = 2.0;

        expectedLocation = new Point2D(2.0, 3.0);
    }
}
