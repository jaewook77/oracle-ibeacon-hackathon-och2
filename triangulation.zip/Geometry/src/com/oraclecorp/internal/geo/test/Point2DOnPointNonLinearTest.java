package com.oraclecorp.internal.geo.test;

import org.junit.Before;

import com.oraclecorp.internal.geo.Point2D;

public class Point2DOnPointNonLinearTest extends Point2DTestBase
{

    @Override
    @Before
    public void setUp() throws Exception
    {
        super.setUp();
        
        point1 = new Point2D(3.0, 3.0);
        point2 = new Point2D(4.0, 4.0);
        point3 = new Point2D(5.0, 8.0);

        distance1 = Math.sqrt(2.0);
        distance2 = 0.0;
        distance3 = Math.sqrt(17.0);

        expectedLocation = new Point2D(4.0, 4.0);
    }

}
