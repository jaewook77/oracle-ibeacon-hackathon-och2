/**
 * 
 */
package com.oraclecorp.internal.geo.test;

import org.junit.After;
import org.junit.Before;

import com.oraclecorp.internal.geo.Point2D;

/**
 * @author cpilon
 *
 */
public class Point3DTestBase
{
    protected static final double epsilon = 0.0001;
    protected Point2D point1, point2, point3, point4, expectedLocation;
    protected double distance1, distance2, distance3, distance4;

    public Point3DTestBase()
    {
    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception
    {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception
    {
    }
    
}

