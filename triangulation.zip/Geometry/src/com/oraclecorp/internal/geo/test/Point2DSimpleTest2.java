package com.oraclecorp.internal.geo.test;

import org.junit.Before;

import com.oraclecorp.internal.geo.Point2D;

public class Point2DSimpleTest2 extends Point2DTestBase
{
    @Override
    @Before
    public void setUp() throws Exception
    {
        super.setUp();
        
        point1 = new Point2D(2.0, 1.0);
        point2 = new Point2D(2.0, 4.0);
        point3 = new Point2D(5.0, 4.0);

        double sqrt4_5 = Math.sqrt(4.5);
        distance1 = sqrt4_5;
        distance2 = sqrt4_5;
        distance3 = sqrt4_5;

        expectedLocation = new Point2D(3.5, 2.5);
    }
}
