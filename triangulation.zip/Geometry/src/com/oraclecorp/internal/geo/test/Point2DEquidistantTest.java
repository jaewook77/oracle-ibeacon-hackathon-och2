package com.oraclecorp.internal.geo.test;

import org.junit.Before;

import com.oraclecorp.internal.geo.Point2D;

public class Point2DEquidistantTest extends Point2DTestBase
{

    @Override
    @Before
    public void setUp() throws Exception
    {
        super.setUp();
        
        point1 = new Point2D(2.0, 1.0);
        point2 = new Point2D(2.0, 4.0);
        point3 = new Point2D(5.0, 4.0);

        double distance = Math.sqrt((1.5 * 1.5) + (1.5 * 1.5));
        distance1 = distance;
        distance2 = distance;
        distance3 = distance;
        
        expectedLocation = new Point2D(3.5, 2.5);
    }
}
