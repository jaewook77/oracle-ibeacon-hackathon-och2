/**
 * 
 */
package com.oraclecorp.internal.geo.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.oraclecorp.internal.geo.Point2D;

/**
 * @author cpilon
 *
 */
public class Point2DTestBase
{
    protected static final double epsilon = 0.0001;
    protected Point2D point1, point2, point3, expectedLocation;
    protected double distance1, distance2, distance3;

    public Point2DTestBase()
    {
    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception
    {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception
    {
    }
    
    @Test
    public void test123()
    {
        Point2D location = Point2D.trilaterate(point1, distance1, point2, distance2, point3, distance3, epsilon);
        assertTrue((location == null && expectedLocation == null) || (location != null && Math.abs(location.x - expectedLocation.x) < epsilon && Math.abs(location.y - expectedLocation.y) < epsilon));
    }

    @Test
    public void test132()
    {
        Point2D location = Point2D.trilaterate(point1, distance1, point3, distance3, point2, distance2, epsilon);
        assertTrue((location == null && expectedLocation == null) || (location != null && Math.abs(location.x - expectedLocation.x) < epsilon && Math.abs(location.y - expectedLocation.y) < epsilon));
    }

    @Test
    public void test213()
    {
        Point2D location = Point2D.trilaterate(point2, distance2, point1, distance1, point3, distance3, epsilon);
        assertTrue((location == null && expectedLocation == null) || (location != null && Math.abs(location.x - expectedLocation.x) < epsilon && Math.abs(location.y - expectedLocation.y) < epsilon));
    }

    @Test
    public void test231()
    {
        Point2D location = Point2D.trilaterate(point2, distance2, point3, distance3, point1, distance1, epsilon);
        assertTrue((location == null && expectedLocation == null) || (location != null && Math.abs(location.x - expectedLocation.x) < epsilon && Math.abs(location.y - expectedLocation.y) < epsilon));
    }

    @Test
    public void test312()
    {
        Point2D location = Point2D.trilaterate(point3, distance3, point1, distance1, point2, distance2, epsilon);
        assertTrue((location == null && expectedLocation == null) || (location != null && Math.abs(location.x - expectedLocation.x) < epsilon && Math.abs(location.y - expectedLocation.y) < epsilon));
    }

    @Test
    public void test321()
    {
        Point2D location = Point2D.trilaterate(point3, distance3, point2, distance2, point1, distance1, epsilon);
        assertTrue((location == null && expectedLocation == null) || (location != null && Math.abs(location.x - expectedLocation.x) < epsilon && Math.abs(location.y - expectedLocation.y) < epsilon));
    }

}

