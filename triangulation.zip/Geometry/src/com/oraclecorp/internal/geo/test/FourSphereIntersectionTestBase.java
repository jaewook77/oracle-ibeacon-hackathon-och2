package com.oraclecorp.internal.geo.test;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;

import com.oraclecorp.internal.geo.Point3D;
import com.oraclecorp.internal.geo.Sphere;
import com.oraclecorp.internal.geo.SphereIntersector;

public class FourSphereIntersectionTestBase
{
    protected Sphere sphere1;
    protected Sphere sphere2;
    protected Sphere sphere3;
    protected Sphere sphere4;
    protected double epsilon;
    protected Point3D expectedValue;
 
    public FourSphereIntersectionTestBase()
    {
    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception
    {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception
    {
    }
    
    public void testSphereEquations()
    {
        List<Sphere> spheres = Arrays.asList(sphere1, sphere2, sphere3, sphere4);
        testSphereEquations(spheres, 0);
    }
    
    protected void testSphereEquations(List<Sphere> spheres, int index)
    {
        for (int i = index; i < spheres.size(); i++)
        {
            java.util.Collections.swap(spheres, i, index);
            testSphereEquations(spheres, index+1);
            java.util.Collections.swap(spheres, index, i);
        }
        
        if (index == spheres.size() - 1)
            testSphereEquationPermutation(spheres);
    }
    
    protected void testSphereEquationPermutation(List<Sphere> spheres)
    {
        Sphere sphereA = spheres.get(0);
        Sphere sphereB = spheres.get(1);
        Sphere sphereC = spheres.get(2);
        Sphere sphereD = spheres.get(3);
        
        Point3D intersection = SphereIntersector.getIntersection(sphereA, sphereB, sphereC, sphereD, epsilon);
        
        // NOTE: This is just one test instead of 4 because the intersection isn't correct unless
        // all of the equations are true.
        assertTrue(
            Math.abs(
                (intersection.x - sphereA.center.x)*(intersection.x - sphereA.center.x)
                + (intersection.y - sphereA.center.y)*(intersection.y - sphereA.center.y)
                + (intersection.z - sphereA.center.z)*(intersection.z - sphereA.center.z)
                - (sphereA.radius * sphereA.radius)) < epsilon
                
            && Math.abs(
                (intersection.x - sphereB.center.x)*(intersection.x - sphereB.center.x)
                + (intersection.y - sphereB.center.y)*(intersection.y - sphereB.center.y)
                + (intersection.z - sphereB.center.z)*(intersection.z - sphereB.center.z)
                - (sphereB.radius * sphereB.radius)) < epsilon
                
            && Math.abs(
                (intersection.x - sphereC.center.x)*(intersection.x - sphereC.center.x)
                + (intersection.y - sphereC.center.y)*(intersection.y - sphereC.center.y)
                + (intersection.z - sphereC.center.z)*(intersection.z - sphereC.center.z)
                - (sphereC.radius * sphereC.radius)) < epsilon
                
            && Math.abs(
                (intersection.x - sphereD.center.x)*(intersection.x - sphereD.center.x)
                + (intersection.y - sphereD.center.y)*(intersection.y - sphereD.center.y)
                + (intersection.z - sphereD.center.z)*(intersection.z - sphereD.center.z)
                - (sphereD.radius * sphereD.radius)) < epsilon
                                
                );
    }
    
    public void testExpectedValue()
    {
        List<Sphere> spheres = Arrays.asList(sphere1, sphere2, sphere3, sphere4);
        testExpectedValue(spheres, 0);
    }
    
    protected void testExpectedValue(List<Sphere> spheres, int index)
    {
        for (int i = index; i < spheres.size(); i++)
        {
            java.util.Collections.swap(spheres, i, index);
            testExpectedValue(spheres, index+1);
            java.util.Collections.swap(spheres, index, i);
        }
        
        if (index == spheres.size() - 1)
            testExpectedValuePermutation(spheres);

    }
    
    protected void testExpectedValuePermutation(List<Sphere> spheres)
    {
        Sphere sphereA = spheres.get(0);
        Sphere sphereB = spheres.get(1);
        Sphere sphereC = spheres.get(2);
        Sphere sphereD = spheres.get(3);
        
        Point3D intersection = SphereIntersector.getIntersection(sphereA, sphereB, sphereC, sphereD, epsilon);
        
        assertTrue(
           Math.abs(intersection.x - expectedValue.x) < epsilon
               && Math.abs(intersection.y - expectedValue.y) < epsilon
               && Math.abs(intersection.z - expectedValue.z) < epsilon
                 );
        
    }

}
